@echo off
setlocal
title Analogue Pocket SCUMM Adventure Controls Builder

echo.
echo ============================================================
echo   Analogue Pocket SCUMM Adventure Controls - Windows Build
echo ============================================================
echo.
echo Alles Weitere laeuft automatisch.
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1"
set "RESULT=%ERRORLEVEL%"

echo.
if "%RESULT%"=="0" (
    echo ============================================================
    echo   FERTIG
    echo ============================================================
    echo.
    echo Das fertige Pocket-Paket liegt im Ordner:
    echo   %~dp0output
) else (
    echo ============================================================
    echo   BUILD FEHLGESCHLAGEN
    echo ============================================================
    echo.
    echo Fehlercode: %RESULT%
    echo Bitte den kompletten Text aus diesem Fenster kopieren.
)
echo.
pause
exit /b %RESULT%
