param(
    [Parameter(Mandatory=$true)]
    [string]$Repo
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version 2.0
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Read-LF([string]$Path) {
    if (-not (Test-Path $Path)) { throw "Quelldatei fehlt: $Path" }
    return ([System.IO.File]::ReadAllText($Path)).Replace("`r`n","`n").Replace("`r","`n")
}
function Write-LF([string]$Path,[string]$Text) { [System.IO.File]::WriteAllText($Path,$Text,$Utf8NoBom) }
function Insert-Before([string]$Text,[string]$Needle,[string]$Insert,[string]$Label) {
    $i=$Text.IndexOf($Needle,[System.StringComparison]::Ordinal); if($i -lt 0){throw "Source-Anker nicht gefunden ($Label)."}
    return $Text.Substring(0,$i)+$Insert+$Text.Substring($i)
}
function Insert-After([string]$Text,[string]$Needle,[string]$Insert,[string]$Label) {
    $i=$Text.IndexOf($Needle,[System.StringComparison]::Ordinal); if($i -lt 0){throw "Source-Anker nicht gefunden ($Label)."}; $i+=$Needle.Length
    return $Text.Substring(0,$i)+$Insert+$Text.Substring($i)
}
function Replace-First([string]$Text,[string]$Needle,[string]$Replacement,[string]$Label) {
    $i=$Text.IndexOf($Needle,[System.StringComparison]::Ordinal); if($i -lt 0){throw "Source-Anker nicht gefunden ($Label)."}
    return $Text.Substring(0,$i)+$Replacement+$Text.Substring($i+$Needle.Length)
}
function Enable-AdventureIni([string]$Path) {
    if(-not(Test-Path $Path)){ Write-Host "Hinweis: OS-INI fehlt, uebersprungen: $Path" -ForegroundColor Yellow; return }
    $t=Read-LF $Path
    if($t -notmatch "(?m)^adventure_controls=true$"){ if(-not $t.EndsWith("`n")){$t+="`n"}; $t+="adventure_controls=true`n"; Write-LF $Path $t }
}

$Main=Join-Path $Repo "src\scummvm\main.cpp"
$Backend=Join-Path $Repo "src\scummvm\backend\openfpga_osystem.cpp"
$ScummH=Join-Path $Repo "src\scummvm\scummvm\engines\scumm\scumm.h"
$Input=Join-Path $Repo "src\scummvm\scummvm\engines\scumm\input.cpp"
$ScummCpp=Join-Path $Repo "src\scummvm\scummvm\engines\scumm\scumm.cpp"
$GfxGui=Join-Path $Repo "src\scummvm\scummvm\engines\scumm\gfx_gui.cpp"
$Monkey1Ini=Join-Path $Repo "dist\scummvm\Assets\scummvm\common\monkey1_os.ini"
$Monkey2Ini=Join-Path $Repo "dist\scummvm\Assets\scummvm\common\monkey2_os.ini"
$TentacleIni=Join-Path $Repo "dist\scummvm\Assets\scummvm\common\tentacle_os.ini"
$HeaderBlock=([System.IO.File]::ReadAllText((Join-Path $Root "snippet-scumm-h.txt"))).Replace("`r`n","`n")
$InputImpl=([System.IO.File]::ReadAllText((Join-Path $Root "snippet-input-impl.txt"))).Replace("`r`n","`n")
$InputHook=([System.IO.File]::ReadAllText((Join-Path $Root "snippet-input-hook.txt"))).Replace("`r`n","`n")
$CursorBlock=([System.IO.File]::ReadAllText((Join-Path $Root "snippet-cursor-block.txt"))).Replace("`r`n","`n")
# v20 guard: source snippets must contain real indentation, never a literal "\t"
# at the start of a C++ line.
foreach ($pair in @(
    @("snippet-scumm-h.txt", $HeaderBlock),
    @("snippet-input-impl.txt", $InputImpl),
    @("snippet-input-hook.txt", $InputHook),
    @("snippet-cursor-block.txt", $CursorBlock)
)) {
    if ($pair[1] -match '(?m)^\\t') {
        throw "v20 check: $($pair[0]) enthaelt literales Backslash-t statt Einrueckung."
    }
}


# main.cpp
$t=Read-LF $Main
if($t -notmatch "bool adventure_controls"){$t=Insert-Before $t "    bool voices;" "    bool adventure_controls; /* MI1/MI2/DOTT handheld controls. */`n" "main GameConfig"}
if($t -notmatch "cfg\.adventure_controls"){
    $a='    cfg.cd_track_offset = of_config_get_int("scummvm", "cd_track_offset", 0);'
    $t=Insert-After $t $a "`n    cfg.adventure_controls = of_config_get_bool(`"scummvm`", `"adventure_controls`", 0) != 0;" "main config read"
}
if($t -notmatch "void openfpga_set_adventure_controls"){$t=Insert-After $t '#include "backend/openfpga_save.h"' "`nvoid openfpga_set_adventure_controls(bool enabled);" "main setter decl"}
if($t -notmatch "openfpga_set_adventure_controls\(cfgLoaded"){$t=Insert-After $t "    bool cfgLoaded = loadGameConfigFromOS(cfg);" "`n    openfpga_set_adventure_controls(cfgLoaded && cfg.adventure_controls);" "main backend switch"}
if($t -notmatch 'ConfMan\.setBool\("openfpga_adventure_controls"'){$t=Insert-After $t '    ConfMan.setBool("use_remastered_audio", cfg.voices, gid);' "`n    ConfMan.setBool(`"openfpga_adventure_controls`", cfg.adventure_controls, gid);" "main ConfMan flag"}
Write-LF $Main $t

# backend: stop built-in controller mouse movement, but leave dock mouse intact.
$t=Read-LF $Backend
if($t -notmatch "g_openfpgaAdventureControls"){
    $ins=@"

static bool g_openfpgaAdventureControls = false;
void openfpga_set_adventure_controls(bool enabled) {
    g_openfpgaAdventureControls = enabled;
}
"@
    $ins=$ins.Replace("`r`n","`n")
    $t=Insert-After $t "static bool g_pumpBusy = false;" $ins "backend adventure flag"
}
$old=@"
    int rateX = 0;
    int rateY = 0;
    if (lx != 0)
        rateX += (lx * analogMaxRate) / 32767;
    if (ly != 0)
        rateY += (ly * analogMaxRate) / 32767;
"@
$new=@"
    int rateX = 0;
    int rateY = 0;
    if (!g_openfpgaAdventureControls) {
        if (lx != 0)
            rateX += (lx * analogMaxRate) / 32767;
        if (ly != 0)
            rateY += (ly * analogMaxRate) / 32767;
    }
"@
$old=$old.Replace("`r`n","`n"); $new=$new.Replace("`r`n","`n")
if($t -notmatch "if \(!g_openfpgaAdventureControls\) \{\s*if \(lx != 0\)"){$t=Replace-First $t $old $new "backend analog suppression"}
$old=@"
    int dpadX = 0;
    int dpadY = 0;
    if (state.buttons & OF_BTN_LEFT)  --dpadX;
    if (state.buttons & OF_BTN_RIGHT) ++dpadX;
    if (state.buttons & OF_BTN_UP)    --dpadY;
    if (state.buttons & OF_BTN_DOWN)  ++dpadY;
"@
$new=@"
    int dpadX = 0;
    int dpadY = 0;
    if (!g_openfpgaAdventureControls) {
        if (state.buttons & OF_BTN_LEFT)  --dpadX;
        if (state.buttons & OF_BTN_RIGHT) ++dpadX;
        if (state.buttons & OF_BTN_UP)    --dpadY;
        if (state.buttons & OF_BTN_DOWN)  ++dpadY;
    }
"@
$old=$old.Replace("`r`n","`n"); $new=$new.Replace("`r`n","`n")
if($t -notmatch "if \(!g_openfpgaAdventureControls\) \{\s*if \(state\.buttons & OF_BTN_LEFT\)"){$t=Replace-First $t $old $new "backend dpad suppression"}
$t=$t.Replace("if (gPocketControls.a.configured) {","if (gPocketControls.a.configured && !g_openfpgaAdventureControls) {")
$t=$t.Replace("if (gPocketControls.b.configured) {","if (gPocketControls.b.configured && !g_openfpgaAdventureControls) {")
$t=$t.Replace("if (gPocketControls.x.configured) {","if (gPocketControls.x.configured && !g_openfpgaAdventureControls) {")
if($t -notmatch "gPocketControls\.a\.configured && !g_openfpgaAdventureControls"){throw "Backend A nicht angepasst."}
if($t -notmatch "gPocketControls\.b\.configured && !g_openfpgaAdventureControls"){throw "Backend B nicht angepasst."}
if($t -notmatch "gPocketControls\.x\.configured && !g_openfpgaAdventureControls"){throw "Backend X nicht angepasst."}
Write-LF $Backend $t

# scumm.h
$t=Read-LF $ScummH
if($t -notmatch '#include "common/array.h"'){$t=Insert-After $t '#include "engines/engine.h"' "`n`n#include `"common/array.h`"" "scumm array include"}
if($t -notmatch "enum OpenFPGAAdventureMode"){
    $p=$t.IndexOf("void parseEvents()",[System.StringComparison]::Ordinal); if($p -lt 0){throw "scumm.h parseEvents fehlt"}
    $q=$t.IndexOf("protected:",$p,[System.StringComparison]::Ordinal); if($q -lt 0){throw "scumm.h protected fehlt"}
    $t=$t.Substring(0,$q)+$HeaderBlock+"`n"+$t.Substring($q)
}
Write-LF $ScummH $t

# input.cpp
$t=Read-LF $Input
if($t -notmatch '#include "scumm/actor.h"'){$t=Insert-Before $t '#include "scumm/debugger.h"' "#include `"scumm/actor.h`"`n#include `"scumm/object.h`"`n#include `"scumm/verbs.h`"`n" "input includes"}
if($t -notmatch '#include <of.h>'){$t=Replace-First $t 'extern "C" void openfpga_midi_panic(void);' "extern `"C`" {`n#include <of.h>`n}`nextern `"C`" void openfpga_midi_panic(void);" "input of.h"}
if($t -notmatch "bool ScummEngine::openFPGAAdventureControlsEnabled"){$t=Insert-Before $t "void ScummEngine::processInput() {" ($InputImpl+"`n") "input implementation"}
if($t -notmatch "v20 Pocket Adventure event gate"){
$gate=@"
void ScummEngine::parseEvent(Common::Event event) {
#ifdef NONSTANDARD_PORT
\t// v20 Pocket Adventure event gate.
\tif (openFPGAAdventureControlsEnabled() && !_mainMenuIsActive) {
\t\tif ((event.type == Common::EVENT_KEYDOWN || event.type == Common::EVENT_KEYUP) &&
\t\t\tevent.kbd.keycode == Common::KEYCODE_RETURN) {
\t\t\tif (event.type == Common::EVENT_KEYDOWN)
\t\t\t\t_openFPGAAdventureToggleRequested = true;
\t\t\treturn;
\t\t}
\t\tif (event.type == Common::EVENT_MOUSEMOVE)
\t\t\treturn;
\t\tif (_openFPGAAdventureMode == kOpenFPGAWalk &&
\t\t\t(event.type == Common::EVENT_LBUTTONDOWN || event.type == Common::EVENT_LBUTTONUP ||
\t\t\t event.type == Common::EVENT_RBUTTONDOWN || event.type == Common::EVENT_RBUTTONUP))
\t\t\treturn;
\t}
#endif
"@
    $gate=$gate.Replace("`r`n","`n").Replace("\t","`t")
    $t=Replace-First $t "void ScummEngine::parseEvent(Common::Event event) {" $gate "input parseEvent gate"
}
if($t -notmatch "v20 controller owner"){$t=Insert-Before $t "`t// Determine the mouse button state." ($InputHook+"`n`t//`n") "input controller hook"}
Write-LF $Input $t

# scumm.cpp cursor ownership only
$t=Read-LF $ScummCpp
if($t -notmatch "v20: direct walking hides the cursor"){
    $p=$t.IndexOf("`t/* show or hide mouse */",[System.StringComparison]::Ordinal); if($p -lt 0){throw "cursor comment fehlt"}
    $needle="`tCursorMan.showMouse(_cursor.state > 0);"; $q=$t.IndexOf($needle,$p,[System.StringComparison]::Ordinal); if($q -lt 0){throw "CursorMan anchor fehlt"}
    $t=$t.Substring(0,$q)+$CursorBlock.TrimEnd()+$t.Substring($q+$needle.Length)
}
Write-LF $ScummCpp $t


# input.cpp: Pocket integration inside waitForBannerInput(), whose implementation
# lives here in current openfpgaOS/ScummVM main (not in gfx_gui.cpp).
$t=Read-LF $Input
if($t -notmatch "v20 Pocket menu navigation"){
    $fn="void ScummEngine::waitForBannerInput("
    $p=$t.IndexOf($fn,[System.StringComparison]::Ordinal)
    if($p -lt 0){throw "v20: waitForBannerInput() nicht in input.cpp gefunden"}
    $brace=$t.IndexOf("{",$p,[System.StringComparison]::Ordinal)
    if($brace -lt 0){throw "v20: waitForBannerInput()-Body fehlt"}
    $next=$t.IndexOf("void ScummEngine_v6::processKeyboard",$brace,[System.StringComparison]::Ordinal)
    if($next -lt 0){$next=$t.IndexOf("void ScummEngine::processKeyboard",$brace,[System.StringComparison]::Ordinal)}
    if($next -lt 0){throw "v20: Ende des waitForBannerInput()-Bereichs nicht gefunden"}

    $head=$t.Substring(0,$brace+1)
    $body=$t.Substring($brace+1,$next-($brace+1))
    $tail=$t.Substring($next)

    # The blocking menu path uses waitForTimer(1, true). Other banner paths may
    # use the one-argument form, so patch both safely under _mainMenuIsActive.
    $needle1="waitForTimer(1); // Allow the engine to update the screen and fetch new inputs..."
    $repl1="waitForTimer(1); // Allow the engine to update the screen and fetch new inputs...`n#ifdef NONSTANDARD_PORT`n`t`t`t// v20 Pocket menu navigation`n`t`t`tif (openFPGAAdventureControlsEnabled() && _mainMenuIsActive)`n`t`t`t`topenFPGAAdventureHandleMenuNavigation();`n#endif"
    if($body.IndexOf($needle1,[System.StringComparison]::Ordinal) -ge 0){$body=$body.Replace($needle1,$repl1)}

    $needle2="waitForTimer(1, true); // Allow the engine to update the screen and fetch new inputs..."
    $repl2="waitForTimer(1, true); // Allow the engine to update the screen and fetch new inputs...`n#ifdef NONSTANDARD_PORT`n`t`t// v20 Pocket menu navigation`n`t`tif (openFPGAAdventureControlsEnabled() && _mainMenuIsActive)`n`t`t`topenFPGAAdventureHandleMenuNavigation();`n#endif"
    if($body.IndexOf($needle2,[System.StringComparison]::Ordinal) -lt 0){throw "v20: blockierender waitForTimer(1, true)-Anker fehlt"}
    $body=$body.Replace($needle2,$repl2)
    $t=$head+$body+$tail
    Write-LF $Input $t
}

# gfx_gui.cpp: START/Quit integration for SCUMM's original F5 menu.
$t=Read-LF $GfxGui

if($t -notmatch "v20 START closes original menu"){
    $show=$t.IndexOf("void ScummEngine::showMainMenu()",[System.StringComparison]::Ordinal)
    if($show -lt 0){throw "v20: showMainMenu() nicht gefunden"}

    $wait=$t.IndexOf("waitForBannerInput(-1, ks, leftMsClicked, rightMsClicked",$show,[System.StringComparison]::Ordinal)
    if($wait -lt 0){throw "v20: Haupt-Menue waitForBannerInput() nicht gefunden"}
    $semi=$t.IndexOf(";",$wait,[System.StringComparison]::Ordinal)
    if($semi -lt 0){throw "v20: Ende des Menue-Waits nicht gefunden"}

    $ins=@"

#ifdef NONSTANDARD_PORT
		// v20 START closes original menu.
		if (openFPGAAdventureControlsEnabled() && ks.keycode == Common::KEYCODE_F5) {
			clearClickedStatus();
			break;
		}
#endif
"@
    $ins=$ins.Replace("`r`n","`n").Replace("\t","`t")
    $t=$t.Substring(0,$semi+1)+$ins+$t.Substring($semi+1)
}

if($t -notmatch "v20 Pocket-safe original Quit"){
    $exec=$t.IndexOf("bool ScummEngine::executeMainMenuOperation(",[System.StringComparison]::Ordinal)
    if($exec -lt 0){throw "v20: executeMainMenuOperation() nicht gefunden"}
    $brace=$t.IndexOf("{",$exec,[System.StringComparison]::Ordinal)
    if($brace -lt 0){throw "v20: executeMainMenuOperation()-Body fehlt"}

    $ins=@"

#ifdef NONSTANDARD_PORT
	// v20 Pocket-safe original Quit.
	if (openFPGAAdventureControlsEnabled() && op == GUI_CTRL_QUIT_BUTTON)
		return true;
#endif
"@
    $ins=$ins.Replace("`r`n","`n").Replace("\t","`t")
    $t=$t.Substring(0,$brace+1)+$ins+$t.Substring($brace+1)
}

Write-LF $GfxGui $t


Enable-AdventureIni $Monkey1Ini
Enable-AdventureIni $Monkey2Ini
Enable-AdventureIni $TentacleIni

# fail-fast assertions
$mc=Read-LF $Main; $bc=Read-LF $Backend; $ic=Read-LF $Input; $sc=Read-LF $ScummCpp
if($mc -notmatch "openfpga_set_adventure_controls\(cfgLoaded && cfg\.adventure_controls\)"){throw "v20 check: main/backend switch fehlt"}
if($bc -notmatch "if \(!g_openfpgaAdventureControls\) \{\s*if \(state\.buttons & OF_BTN_LEFT\)"){throw "v20 check: D-pad backend suppression fehlt"}
if($ic -notmatch "v20 Pocket Adventure event gate"){throw "v20 check: event gate fehlt"}
if($ic -notmatch "EVENT_LBUTTONDOWN"){throw "v20 check: A/B gate fehlt"}
if($sc -notmatch "_openFPGAAdventureMode == kOpenFPGACursor"){throw "v20 check: cursor ownership fehlt"}
$gc=Read-LF $GfxGui
if($ic -notmatch "GID_MONKEY_VGA"){throw "v20 check: MI1 VGA game-id support fehlt"}
if($gc -notmatch "v20 START closes original menu"){throw "v20 check: START-Menue-Close fehlt"}
if($gc -notmatch "v20 Pocket-safe original Quit"){throw "v20 check: Pocket-safe Ende-Behandlung fehlt"}
if($ic -notmatch "v20 Pocket menu navigation"){throw "v20 check: D-Pad-Menue-Navigation fehlt"}
if($ic -notmatch "const bool xPressed = xNow && !_openFPGAPrevX"){throw "v20 check: direkter X-Flankentoggle fehlt"}


# Final source-tree sanity check for the exact v17 regression.
foreach ($srcFile in @($ScummH, $Input, $ScummCpp, $GfxGui)) {
    $srcText = Read-LF $srcFile
    if ($srcText -match '(?m)^\\t') {
        throw "v20 check: Literales Backslash-t im gepatchten C++ gefunden: $srcFile"
    }
}

Write-Host "v20 Adventure Controls erfolgreich und konsistent eingesetzt." -ForegroundColor Green
