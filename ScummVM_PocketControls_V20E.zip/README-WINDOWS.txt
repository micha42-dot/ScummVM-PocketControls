Analogue Pocket – SCUMM Adventure Controls
WINDOWS BUILDER v20

v11 entfernt die letzten Altlasten des alten git-Patch-Workflows vollständig.
Es gibt keine $Patch- oder $PatchMsys-Variable mehr.

Ablauf:
- MSYS2/UCRT64-Toolchain prüfen
- Repository unter %LOCALAPPDATA%\APSCUMMBuild\ScummVM vorbereiten
- Adventure-Controls per apply-controls.ps1 direkt in den aktuellen Source einsetzen
- nativer Build mit USE_SDK_CONTAINER=0
- Ergebnis nach output\ neben build.bat kopieren

Einfach die Dateien aus diesem ZIP über die bisherige Version kopieren und
build.bat starten.




v12:

- Behebt Sam & Max (DOS Floppy): Der Pocket-Fork band den cprot-Bypass an kEnhUIUX.

- v12 bindet den Bypass wieder an copy_protection=false, sodass die originale

  Disketten-Kopierschutzsequenz nicht in den Pocket-Debugger laeuft.





v19 - bereinigte MI1/MI2/DOTT-Fassung

- D-Pad normal: Spielfigur direkt laufen.
- X: Walk <-> originaler SCUMM-Cursor.
- D-Pad im Cursor-Modus: raeumlich Szene / Verben / sichtbare UI-Inventar-Slots.
- A/B im Cursor-Modus: echte originale Pocket-Mausevents.
- Kein eigenes Verb-Popup, kein doSentence().
- Sam & Max ist bewusst nicht Teil dieser Fassung.

Technische Aenderungen:
- Native Pocket-D-Pad/Analog-Cursorbewegung wird im Backend deaktiviert, sobald
  adventure_controls=true aktiv ist.
- X bleibt das echte Return-Event; KEYDOWN toggelt, KEYDOWN/KEYUP werden geschluckt.
- A/B werden im Walk-Modus geschluckt und im Cursor-Modus original durchgereicht.
- Cursor wird im Snap-Modus explizit sichtbar, im Walk-Modus unsichtbar.
- Stoppen: einmal Standframe starten, dann aktiven Laufweg beenden. Keine Settle-Schleife.
- monkey1_os.ini, monkey2_os.ini und tentacle_os.ini werden automatisch aktiviert,
  sofern sie im aktuellen Repo vorhanden sind.

WICHTIG: Eigene *_os.ini-Dateien auf der SD-Karte brauchen unter [scummvm] weiterhin:

adventure_controls=true

Der Windows/MSYS2-Buildweg selbst ist gegenueber der funktionierenden Builder-Serie unveraendert.




v19 Build-Fix:

- v17 schrieb in mehrere C++-Snippets die Zeichenfolge Backslash+t statt echter Einrueckung.

- Alle verbatim eingefuegten C++-Snippets wurden korrigiert.

- Der parseEvent()-Block aus apply-controls.ps1 normalisiert seine Einrueckung ebenfalls.

- Neue Vorher-/Nachher-Pruefungen stoppen den Builder, falls der Fehler je wieder auftaucht.

- Die v19 Input-Architektur ist ansonsten identisch mit der zuletzt geprueften v17-Architektur.





v19 – MI1-ID + F5-Menue:

- Klassisches MI1 VGA/EGA nutzt GID_MONKEY_VGA/GID_MONKEY_EGA; beide sind jetzt freigeschaltet.

- Walk ist bei MI1 wieder Default; X schaltet bewusst in/aus dem Snap-Cursor.

- Im originalen F5-Menue pausieren die Adventure Controls.

- D-Pad snappt zwischen den echten SCUMM-Menue-Controls.

- A/B und X bleiben im Menue originale SCUMM-Eingaben.

- START/F5 schliesst das Menue wieder direkt.

- Ende/Quit schliesst auf Pocket sicher das Menue statt den Core-Prozess zu beenden.

  Zum Verlassen des Cores die Pocket-Systemoberflaeche benutzen.



v20 – X-Toggle + aktuelles F5-Menue

- Behebt den Build-Abbruch "waitForBannerInput() nicht in gfx_gui.cpp gefunden".
  Die Funktion liegt im aktuellen openfpgaOS/ScummVM-main in input.cpp; der
  Patcher setzt die D-Pad-Menue-Navigation jetzt dort ein.
- X wird zusaetzlich direkt als Pocket-Button-Flanke gelesen. Das Return-Event
  bleibt als Fallback erhalten, kann den Moduswechsel aber nicht mehr verlieren.
- Cursor -> Walk wird vor Room/UserPut/Ego-Pruefungen verarbeitet. Dadurch kann
  der Cursor-Modus auch dann immer mit X verlassen werden, wenn der Actor gerade
  unsichtbar oder temporaer nicht steuerbar ist.
- X wird waehrend des originalen F5-Menues synchronisiert, damit das Schliessen
  oder Bestaetigen im Menue keinen unbeabsichtigten Cursor-Toggle danach ausloest.
