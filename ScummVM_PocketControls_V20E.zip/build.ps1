﻿$ErrorActionPreference = "Stop"

Set-StrictMode -Version 2.0


$Root = Split-Path -Parent $MyInvocation.MyCommand.Path

$Work = Join-Path $env:LOCALAPPDATA "APSCUMMBuild"

$Repo = Join-Path $Work "ScummVM"

$Output = Join-Path $Root "output"


function Step([string]$Text) {

    Write-Host ""

    Write-Host "==> $Text" -ForegroundColor Cyan

}


function Run-Native([string]$Exe, [string[]]$Args) {

    & $Exe @Args

    $code = $LASTEXITCODE

    if ($code -ne 0) {

        throw "$Exe wurde mit Fehlercode $code beendet."

    }

}


function Test-MsysRoot([string]$Path) {

    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }

    return (Test-Path (Join-Path $Path "usr\bin\bash.exe"))

}


function Get-MsysRoot {

    $candidates = New-Object System.Collections.Generic.List[string]


    $candidates.Add("C:\msys64")

    if ($env:LOCALAPPDATA) { $candidates.Add((Join-Path $env:LOCALAPPDATA "Programs\MSYS2")) }

    if ($env:ProgramFiles) { $candidates.Add((Join-Path $env:ProgramFiles "MSYS2")) }

    ${pf86} = [Environment]::GetEnvironmentVariable("ProgramFiles(x86)")

    if (${pf86}) { $candidates.Add((Join-Path ${pf86} "MSYS2")) }


    # Falls MSYS2 an einem benutzerdefinierten Ort installiert wurde,

    # nach InstallLocation in den Uninstall-Registry-Eintraegen schauen.

    $regPaths = @(

        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",

        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",

        "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"

    )

    foreach ($rp in $regPaths) {

        try {

            Get-ItemProperty $rp -ErrorAction SilentlyContinue |

                Where-Object { $_.DisplayName -like "MSYS2*" } |

                ForEach-Object {

                    if ($_.InstallLocation) { $candidates.Add([string]$_.InstallLocation) }

                }

        } catch {}

    }


    # Manche Paketmanager legen Metadaten unter WinGet\Packages ab.

    if ($env:LOCALAPPDATA) {

        $wg = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Packages"

        if (Test-Path $wg) {

            Get-ChildItem $wg -Directory -Filter "MSYS2.MSYS2*" -ErrorAction SilentlyContinue |

                ForEach-Object { $candidates.Add($_.FullName) }

        }

    }


    foreach ($candidate in ($candidates | Select-Object -Unique)) {

        if (Test-MsysRoot $candidate) { return $candidate }


        # In seltenen Faellen ist innerhalb des Kandidaten noch ein msys64-Unterordner.

        $nested = Join-Path $candidate "msys64"

        if (Test-MsysRoot $nested) { return $nested }

    }


    return $null

}


function Wait-ForMsys([int]$Seconds = 240) {

    $deadline = (Get-Date).AddSeconds($Seconds)

    $lastMessage = Get-Date

    do {

        $found = Get-MsysRoot

        if ($found) { return $found }


        if (((Get-Date) - $lastMessage).TotalSeconds -ge 10) {

            Write-Host "MSYS2-Installation laeuft noch; warte auf usr\bin\bash.exe ..."

            $lastMessage = Get-Date

        }

        Start-Sleep -Seconds 2

    } while ((Get-Date) -lt $deadline)


    return $null

}


function Bash([string]$Command) {

    $oldMsystem = $env:MSYSTEM

    $oldChere = $env:CHERE_INVOKING

    try {

        $env:MSYSTEM = "UCRT64"

        $env:CHERE_INVOKING = "1"

        & $script:BashExe -lc "export PATH=/ucrt64/bin:/usr/bin:`$PATH; $Command"

        $code = $LASTEXITCODE

        if ($code -ne 0) {

            throw "MSYS2-Befehl wurde mit Fehlercode $code beendet."

        }

    } finally {

        $env:MSYSTEM = $oldMsystem

        $env:CHERE_INVOKING = $oldChere

    }

}


function To-MsysPath([string]$WindowsPath) {

    $escaped = $WindowsPath.Replace("'", "'\''")

    $oldMsystem = $env:MSYSTEM

    $oldChere = $env:CHERE_INVOKING

    try {

        $env:MSYSTEM = "UCRT64"

        $env:CHERE_INVOKING = "1"

        $result = & $script:BashExe -lc "cygpath -u '$escaped'"

        if ($LASTEXITCODE -ne 0) {

            throw "Windows-Pfad konnte nicht in einen MSYS2-Pfad umgewandelt werden."

        }

        return ($result | Select-Object -First 1).Trim()

    } finally {

        $env:MSYSTEM = $oldMsystem

        $env:CHERE_INVOKING = $oldChere

    }

}
Step "Windows-Buildumgebung pruefen"


$MsysRoot = Get-MsysRoot


if (-not $MsysRoot) {

    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue

    if (-not $winget) {

        Write-Host ""

        Write-Host "Windows Package Manager (winget) ist nicht vorhanden." -ForegroundColor Yellow

        Write-Host "Installiere bitte 'App Installer' aus dem Microsoft Store und starte build.bat erneut."

        exit 2

    }


    Write-Host "MSYS2 wurde noch nicht fertig gefunden."

    Write-Host "Pruefe zuerst, ob eine zuvor gestartete Installation noch laeuft ..."

    $MsysRoot = Wait-ForMsys -Seconds 30


    if (-not $MsysRoot) {

        Write-Host "Starte/fortsetze die MSYS2-Installation ueber WinGet ..."
        $wingetArgs = @(
            "install",
            "--id", "MSYS2.MSYS2",
            "-e",
            "--source", "winget",
            "--location", "C:\msys64",
            "--accept-package-agreements",
            "--accept-source-agreements",
            "--silent"
        )
        & $winget.Source @wingetArgs
        $wingetCode = $LASTEXITCODE

        if ($wingetCode -ne 0) {

            # Ein bereits installiertes Paket kann je nach winget-Version einen

            # Sonderstatus liefern. Deshalb trotzdem noch nach der echten Installation suchen.

            Write-Host "WinGet meldete Code $wingetCode; pruefe trotzdem, ob MSYS2 vorhanden ist."

        }


        Write-Host "Warte, bis der MSYS2-Installer wirklich fertig ist ..."

        $MsysRoot = Wait-ForMsys -Seconds 240

    }


    if (-not $MsysRoot) {

        throw "MSYS2 wurde nach der Installation nicht gefunden. Erwartet wurde insbesondere C:\msys64\usr\bin\bash.exe."

    }

}


$script:BashExe = Join-Path $MsysRoot "usr\bin\bash.exe"

Write-Host "MSYS2 gefunden: $MsysRoot" -ForegroundColor Green


Step "MSYS2 initialisieren und Buildpakete installieren"


# Ein erster Bash-Aufruf initialisiert /etc, Home-Verzeichnis und Schluesselbund.

Bash "true"


# Erst die Paketdatenbank aktualisieren. Danach nur die benoetigten Pakete.

Bash "pacman -Sy --needed --noconfirm make patch diffutils zip unzip python mingw-w64-ucrt-x86_64-git mingw-w64-ucrt-x86_64-riscv64-unknown-elf-toolchain && hash -r && command -v git && git --version"


# Verifizieren, dass wir wirklich den UCRT64-RISC-V-Compiler erwischen.

Bash "command -v riscv64-unknown-elf-g++ && riscv64-unknown-elf-g++ --version | head -n 1"


Step "ScummVM-Pocket-Quellcode vorbereiten"

Write-Host "Arbeitsordner: $Work"
Write-Host "Ausgabeordner: $Output"


New-Item -ItemType Directory -Force -Path $Work | Out-Null

New-Item -ItemType Directory -Force -Path $Output | Out-Null


$RepoMsys = To-MsysPath $Repo
$WorkMsys = To-MsysPath $Work


if (-not (Test-Path (Join-Path $Repo ".git"))) {

    Bash "mkdir -p '$WorkMsys' && /ucrt64/bin/git.exe -c core.autocrlf=false -c core.eol=lf clone https://github.com/openfpgaOS/ScummVM.git '$RepoMsys' && /ucrt64/bin/git.exe -C '$RepoMsys' config core.autocrlf false && /ucrt64/bin/git.exe -C '$RepoMsys' config core.eol lf"

} else {

    Bash "/ucrt64/bin/git.exe -C '$RepoMsys' config core.autocrlf false && /ucrt64/bin/git.exe -C '$RepoMsys' config core.eol lf && /ucrt64/bin/git.exe -C '$RepoMsys' fetch origin main && /ucrt64/bin/git.exe -C '$RepoMsys' reset --hard origin/main && /ucrt64/bin/git.exe -C '$RepoMsys' clean -fdx && /ucrt64/bin/git.exe -C '$RepoMsys' checkout-index -a -f"

}


Step "Adventure-Controls in aktuellen Source-Tree einsetzen"


$ApplyScript = Join-Path $Root "apply-controls.ps1"

& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $ApplyScript -Repo $Repo

if ($LASTEXITCODE -ne 0) {

    throw "Adventure-Controls Source-Patcher wurde mit Fehlercode $LASTEXITCODE beendet."

}


Step "SCUMM-Core fuer Analogue Pocket bauen"


Bash "cd '$RepoMsys/src/scummvm' && make USE_SDK_CONTAINER=0 ENGINES=scumm clean && make USE_SDK_CONTAINER=0 ENGINES=scumm"


Step "Pocket-Paket erzeugen"


Bash "cd '$RepoMsys/src/scummvm' && make USE_SDK_CONTAINER=0 ENGINES=scumm package"


Step "Ergebnisse nach output kopieren"


if (Test-Path $Output) {

    Get-ChildItem -LiteralPath $Output -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force

}

New-Item -ItemType Directory -Force -Path $Output | Out-Null


$searchRoots = @(

    (Join-Path $Repo "releases"),

    (Join-Path $Repo "src\scummvm\releases"),

    (Join-Path $Repo "src\scummvm\build-multi"),

    (Join-Path $Repo "src\scummvm\build")

)


$found = @()

foreach ($dir in $searchRoots) {

    if (Test-Path $dir) {

        $found += Get-ChildItem -Path $dir -Recurse -File -ErrorAction SilentlyContinue |

            Where-Object { $_.Extension -eq ".zip" -or $_.Extension -eq ".elf" }

    }

}


$seen = @{}

foreach ($file in $found) {

    $key = $file.FullName.ToLowerInvariant()

    if (-not $seen.ContainsKey($key)) {

        $seen[$key] = $true

        Copy-Item -LiteralPath $file.FullName -Destination $Output -Force

    }

}


$results = Get-ChildItem -LiteralPath $Output -File -ErrorAction SilentlyContinue

if (-not $results) {

    throw "Der Build lief durch, aber es wurde kein ZIP/ELF zum Kopieren gefunden."

}


Write-Host ""

Write-Host "Build erfolgreich." -ForegroundColor Green

Write-Host "Ausgabe:"

foreach ($r in $results) {

    Write-Host ("  " + $r.FullName)

}


exit 0

